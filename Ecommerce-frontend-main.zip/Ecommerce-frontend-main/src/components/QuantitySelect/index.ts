import QuantitySelect from './QuantitySelect'

export default QuantitySelect
