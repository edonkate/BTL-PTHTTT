import InputFile from './InputFile'

export default InputFile
