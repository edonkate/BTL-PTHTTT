import Chatbot from './Chatbot'

export default Chatbot
