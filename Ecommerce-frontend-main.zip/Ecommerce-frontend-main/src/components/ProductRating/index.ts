import ProductRating from './ProductRating'

export default ProductRating
