export const sortField = {
  release_date: 'release_date',
  sold: 'sold',
  price: 'price'
} as const

export const dir = {
  asc: 'ASC',
  desc: 'DESC'
} as const
