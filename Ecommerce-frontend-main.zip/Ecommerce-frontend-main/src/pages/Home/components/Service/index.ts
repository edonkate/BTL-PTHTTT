import Service from './Service'

export default Service
