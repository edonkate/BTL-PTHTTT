import React from 'react'

export default function ProductImage() {
  return <div>ProductImage</div>
}
