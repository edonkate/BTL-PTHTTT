import ProductImage from './ProductImage'

export default ProductImage
