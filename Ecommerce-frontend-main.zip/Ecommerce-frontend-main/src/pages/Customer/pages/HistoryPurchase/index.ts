import HistoryPurchase from './HistoryPurchase'

export default HistoryPurchase
