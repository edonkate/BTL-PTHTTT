export interface ShippingInfo {
  id: number
  address: string
  number: string
}
