export interface Notify {
  id: number
  status: number
  content: String
  date: number
}
