export interface Review {
  id?: number
  commentDate?: number
  content?: string
  rate?: number
  productId?: number
  userImage?: string
  username?: string
}
