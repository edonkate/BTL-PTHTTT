const IP = "http://localhost:8081"
const token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJidWloYW4xMjMiLCJpYXQiOjE3MTMzMTk1OTIsImV4cCI6MTcxMzQwNTk5Mn0.od06hv448OABzaA51EiG-sBEAedMavpLyrhl5tnTbek"
export {IP,token}