const config = {
  BASEURL: "http://localhost:8081/api",
  maxFileSize: 1048576,
};

export default config;
